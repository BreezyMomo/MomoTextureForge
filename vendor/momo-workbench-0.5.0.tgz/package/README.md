# MomoWorkbench

MomoTextureForge、MomoPoseForge、MomoSoundForge 共用的 React 19 工作台。公共组件基于 shadcn/ui Base UI 版的 Nova 样式，布局、外观、多语言与偏好统一在本仓库维护。

## React 组件

导入 `@momo/workbench/react.css` 和 `@momo/workbench/theme-tokens.css`。使用 `WorkbenchProvider` 传入产品自己的 `appearance`、`language` 控制器和翻译接口，渲染 `WorkbenchAppearance`、`WorkbenchLanguageSelect`。按钮、菜单、表单等基础组件也从 `@momo/workbench/react` 导入。

```tsx
import {WorkbenchProvider, WorkbenchAppearance, WorkbenchLanguageSelect} from '@momo/workbench/react';
import '@momo/workbench/theme-tokens.css';
import '@momo/workbench/react.css';

<WorkbenchProvider appearance={appearance} language={language}
  ui={{text: t, format: t, onLanguageChange: language.onLanguageChange}}>
  <WorkbenchAppearance />
  <WorkbenchLanguageSelect />
</WorkbenchProvider>
```

外观弹窗支持七主题、九种控件风格、两种密度、四种页签与四种自定义交互颜色。实时预览与保存分开；取消、Esc、卸载恢复未保存草稿。写入偏好失败时保留弹窗和错误提示。语言选项来自产品配置，用户命名与作品内容不会随界面语言变化。

组件使用 `wb:` Tailwind 前缀和局部基础样式，不引入全局 preflight。主题颜色与密度直接复用 Workbench token；Portal 浮层继承相应 Provider 的完整主题。现有领域编辑器继续使用 `controls.css`、`tabs.css` 与 `dock.css`。React UI 已替代旧的 DOM 外观弹窗、语言 select 绑定器和外观按钮绑定器；不保留平行 UI 接口。

## 数据与布局

- `@momo/workbench/appearance`：`createAppearance({root, storage, storageKey})` 管理主题、预览与保存。没有 storage 适配器时不会自动读取浏览器存储。
- `@momo/workbench/i18n`：`createLanguageController`、`createMessageCatalog` 管理产品配置的语言、词库与插值。
- `@momo/workbench/locales`：共享中英文文案。产品补充领域词库。
- `@momo/workbench/layout`：`createLayoutModel` 管理稳定的面板 ID、布局预设、布局操作与序列化。
- `@momo/workbench/dock`：`createDockWorkspace` 保留稳定的面板容器与画布上下文。传入 `renderMenu: options => mountDockMenu({...options, appearance, language})` 使用统一 React 布局菜单；无菜单渲染器时仅提供布局控制。
- `@momo/workbench/motion`：界面 FLIP、拖动与重排动画。服务按实例创建，使用结束后调用 `dispose()`。

产品拥有面板内容，停靠服务负责移动这些现有节点。关闭或停靠面板时不重建编辑器；隐藏面板在 parking 容器中保留。骨架、IK、图形合成、声音引擎、业务参数和工程格式属于消费产品。偏好不进入工程、资源哈希、撤销历史或导出内容。

## 开发与构建

```powershell
npm ci
npm run build
npm test
npm run test:browser
npm run pack:release
```

`components.json` 固定 Base UI / Nova / lucide / wb 前缀。组件源码通过官方 shadcn CLI 生成，位于 `src/react/components/ui/`。`src/react/styles.css` 将语义颜色、密度和圆角连接到 Workbench。修改公共组件后验证至少两个实际消费产品。

构建生成 ESM、类型声明、CSS 和第三方许可说明。React 是共享 peer 依赖，由消费产品提供同一个 React 实例；其他组件依赖固定版本。业务数据服务仍使用普通 JS，实现与 React 呈现分层。

将同一个 `artifacts/momo-workbench-0.5.0.tgz` 放入三个消费仓库的 `vendor/` 并锁定 `file:vendor/momo-workbench-0.5.0.tgz`，提交包、锁文件和消费代码，使独立克隆后的 `npm ci` 可用。

TextureForge 的浏览器源码仍有未迁移的领域编辑器。它通过安装包内的 `scripts/vendor.mjs --target web/vendor/momo-workbench` 生成数据服务和样式快照，使用 `--check` 校验。React 组件由产品构建器从正式包打包，不复制 UI 实现或手改生成文件。单文件离线版内嵌同一套组件及样式。

## 验证范围

共享测试覆盖实例隔离、存储失败、主题恢复、语言切换、布局生命周期与拖动清理。浏览器检查覆盖完整外观设置、焦点恢复、校验、窄屏、两个独立 Provider 和卸载回滚。三个 Forge 分别进行类型检查、构建与产品回归；公共 UI 的通过不代表新增骨架能力、声音处理或导出功能已完成。
