import { useId, useRef, useState, useEffect, type ComponentProps } from "react";
import {
  THEME_IDS,
  STYLE_IDS,
  DENSITY_IDS,
  TAB_STYLE_IDS,
  COLOR_ROLE_IDS,
  defaultAppearanceColors,
  type AppearancePreferences,
  type ColorRole,
} from "../appearance.js";
import { Button } from "./components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "./components/ui/dialog";
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectGroup,
  SelectItem,
} from "./components/ui/select";
import {
  Field,
  FieldGroup,
  FieldLabel,
  FieldDescription,
} from "./components/ui/field";
import { Input } from "./components/ui/input";
import { useAppearancePreferences, useMessages, useWorkbench } from "./context";

export type WorkbenchChoiceProps = {
  id?: string;
  label: string;
  value: string;
  items: { value: string; label: string }[];
  onValueChange: (value: string) => void;
  className?: string;
  disabled?: boolean;
};
export function WorkbenchChoice({
  id,
  label,
  value,
  items,
  onValueChange,
  className,
  disabled,
}: WorkbenchChoiceProps) {
  return (
    <Select
      value={value}
      items={items}
      onValueChange={(next) => {
        if (next !== null) onValueChange(next);
      }}
    >
      <SelectTrigger
        data-momo-ui=""
        id={id}
        aria-label={label}
        className={className}
        disabled={disabled}
      >
        <SelectValue />
      </SelectTrigger>
      <SelectContent align="start" alignItemWithTrigger={false}>
        <SelectGroup>
          {items.map((item) => (
            <SelectItem
              key={item.value}
              value={item.value}
              data-value={item.value}
            >
              {item.label}
            </SelectItem>
          ))}
        </SelectGroup>
      </SelectContent>
    </Select>
  );
}
export function WorkbenchLanguageSelect({
  id,
  onError,
}: {
  id?: string;
  onError?: (error: unknown) => void;
}) {
  const { language } = useWorkbench(),
    { text } = useMessages();
  return (
    <WorkbenchChoice
      id={id}
      label={text("language.interface")}
      value={language.interfaceLanguage()}
      items={language.SUPPORTED_LANGUAGES.map((item) => ({
        value: item.code,
        label: item.name,
      }))}
      onValueChange={(value) => {
        try {
          language.setLanguage(value);
        } catch (error) {
          onError?.(error);
        }
      }}
    />
  );
}
const tabKeys = {
  classic: "appearance.tabsClassic",
  segmented: "appearance.tabsSegmented",
  pill: "appearance.tabsPill",
  underline: "appearance.tabsUnderline",
};
const validHex = (value: string) => /^#[\da-f]{6}$/i.test(value);
export function WorkbenchAppearance({
  id,
  ...buttonProps
}: Omit<ComponentProps<typeof Button>, "children">) {
  const { appearance } = useWorkbench(),
    preferences = useAppearancePreferences(appearance),
    { text, format } = useMessages();
  const [open, setOpen] = useState(false),
    before = useRef<AppearancePreferences | null>(null),
    accepted = useRef(false),
    trigger = useRef<HTMLButtonElement>(null);
  const [status, setStatus] = useState(""),
    [invalid, setInvalid] = useState<ColorRole | null>(null),
    [advanced, setAdvanced] = useState(false);
  const [hex, setHex] = useState<Record<string, string>>({});
  const uid = useId().replaceAll(":", ""),
    prefix = id === "appearance-settings" ? "appearance" : "appearance-" + uid;
  const palette = appearance.palette();
  const colors = () =>
    Object.fromEntries(
      COLOR_ROLE_IDS.map((role) => [
        role,
        (
          appearance.get().colors[role] ?? appearance.palette().colors[role]
        ).toUpperCase(),
      ]),
    );
  const close = () => {
    if (before.current && !accepted.current) appearance.preview(before.current);
    before.current = null;
    setOpen(false);
  };
  useEffect(
    () => () => {
      if (before.current && !accepted.current)
        appearance.preview(before.current);
    },
    [appearance],
  );
  const preview = (next: AppearancePreferences) => {
    appearance.preview(next);
    setHex(colors());
    setInvalid(null);
    setStatus("");
  };
  const start = () => {
    before.current = appearance.get();
    accepted.current = false;
    setHex(colors());
    setStatus("");
    setInvalid(null);
    setAdvanced(false);
    setOpen(true);
  };
  const color = (role: ColorRole, value: string) => {
    setHex((values) => ({ ...values, [role]: value }));
    setInvalid(null);
    setStatus("");
    if (validHex(value)) {
      const next = appearance.get();
      appearance.preview({
        ...next,
        colors: { ...next.colors, [role]: value },
      });
    }
  };
  const save = () => {
    const bad = COLOR_ROLE_IDS.find((role) => !validHex(hex[role] ?? ""));
    if (bad) {
      setAdvanced(true);
      setInvalid(bad);
      setStatus("appearance.invalidHex");
      return;
    }
    if (!appearance.save(appearance.get())) {
      setStatus("appearance.storageUnavailable");
      return;
    }
    accepted.current = true;
    close();
  };
  return (
    <>
      <Button
        data-momo-ui=""
        variant="outline"
        {...buttonProps}
        id={id}
        ref={trigger}
        onClick={start}
      >
        <span className="momo-theme-dot" aria-hidden="true" />
        {text("appearance.title")}
      </Button>
      <Dialog
        open={open}
        onOpenChange={(value) => {
          if (!value) close();
        }}
      >
        <DialogContent
          showCloseButton={false}
          finalFocus={trigger}
          className="wb:w-[min(880px,calc(100vw-2rem))] wb:sm:max-w-[880px] wb:max-h-[calc(100dvh-2rem)] wb:overflow-y-auto momo-appearance-react"
          onKeyDown={(event) => event.stopPropagation()}
        >
          <DialogHeader>
            <DialogTitle id={prefix + "-title"}>
              {text("appearance.title")}
            </DialogTitle>
            <DialogDescription>
              {text("appearance.independent")}
            </DialogDescription>
          </DialogHeader>
          <div className="wb:grid wb:gap-6 wb:md:grid-cols-2">
            <FieldGroup className="wb:gap-4">
              <Field>
                <FieldLabel htmlFor={prefix + "-theme"}>
                  {text("appearance.theme")}
                </FieldLabel>
                <WorkbenchChoice
                  id={prefix + "-theme"}
                  label={text("appearance.theme")}
                  value={preferences.theme}
                  items={THEME_IDS.map((value) => ({
                    value,
                    label: text("appearance.preset." + value),
                  }))}
                  onValueChange={(theme) =>
                    preview({
                      ...appearance.get(),
                      theme: theme as AppearancePreferences["theme"],
                      colors: defaultAppearanceColors(),
                    })
                  }
                />
                <FieldDescription>
                  {text(
                    "appearance.preset." + preferences.theme + "Description",
                  )}
                </FieldDescription>
              </Field>
              <Field>
                <FieldLabel id={prefix + "-styles-title"}>
                  {text("appearance.style")}
                </FieldLabel>
                <div
                  className="wb:grid wb:grid-cols-3 wb:gap-2"
                  role="group"
                  aria-labelledby={prefix + "-styles-title"}
                >
                  {STYLE_IDS.map((style) => (
                    <Button
                      key={style}
                      variant={
                        preferences.style === style ? "secondary" : "outline"
                      }
                      className="appearance-style-card"
                      data-style={style}
                      aria-pressed={style === preferences.style}
                      title={text("appearance." + style + "Description")}
                      onClick={() => preview({ ...appearance.get(), style })}
                    >
                      {text("appearance." + style)}
                    </Button>
                  ))}
                </div>
                <FieldDescription>
                  {text("appearance." + preferences.style + "Description")}
                </FieldDescription>
              </Field>
              <div className="wb:grid wb:grid-cols-2 wb:gap-3">
                <Field>
                  <FieldLabel>{text("appearance.density")}</FieldLabel>
                  <WorkbenchChoice
                    id={prefix + "-density"}
                    label={text("appearance.density")}
                    value={preferences.density}
                    items={DENSITY_IDS.map((value) => ({
                      value,
                      label: text("appearance." + value),
                    }))}
                    onValueChange={(density) =>
                      preview({
                        ...appearance.get(),
                        density: density as AppearancePreferences["density"],
                      })
                    }
                  />
                </Field>
                <Field>
                  <FieldLabel>{text("appearance.tabs")}</FieldLabel>
                  <WorkbenchChoice
                    id={prefix + "-tabs"}
                    label={text("appearance.tabs")}
                    value={preferences.tabs}
                    items={TAB_STYLE_IDS.map((value) => ({
                      value,
                      label: text(tabKeys[value]),
                    }))}
                    onValueChange={(tabs) =>
                      preview({
                        ...appearance.get(),
                        tabs: tabs as AppearancePreferences["tabs"],
                      })
                    }
                  />
                </Field>
              </div>
              <details
                id={prefix + "-colors"}
                open={advanced}
                onToggle={(event) => setAdvanced(event.currentTarget.open)}
              >
                <summary className="wb:cursor-pointer wb:text-sm wb:mb-3">
                  {text("appearance.customColors")}
                </summary>
                <FieldGroup className="wb:gap-3">
                  <FieldDescription>
                    {text("appearance.customColorsHelp")}
                  </FieldDescription>
                  {COLOR_ROLE_IDS.map((role) => (
                    <Field key={role} data-invalid={invalid === role}>
                      <FieldLabel
                        htmlFor={
                          role === "action"
                            ? prefix + "-hex"
                            : prefix + "-hex-" + role
                        }
                      >
                        {text("appearance.color." + role)}
                      </FieldLabel>
                      <div className="wb:flex wb:gap-2">
                        <Input
                          type="color"
                          aria-label={text("appearance.color." + role)}
                          value={
                            validHex(hex[role] ?? "") ? hex[role] : "#000000"
                          }
                          onChange={(event) => color(role, event.target.value)}
                          className="wb:w-10 wb:p-1"
                        />
                        <Input
                          id={
                            role === "action"
                              ? prefix + "-hex"
                              : prefix + "-hex-" + role
                          }
                          aria-label={format(
                            "appearance.colorHex",
                            text("appearance.color." + role),
                          )}
                          aria-invalid={invalid === role}
                          value={hex[role] ?? ""}
                          maxLength={7}
                          spellCheck={false}
                          onChange={(event) => color(role, event.target.value)}
                        />
                      </div>
                    </Field>
                  ))}
                  <Button
                    variant="outline"
                    data-reset
                    onClick={() =>
                      preview({
                        ...appearance.get(),
                        colors: defaultAppearanceColors(),
                      })
                    }
                  >
                    {text("appearance.reset")}
                  </Button>
                </FieldGroup>
              </details>
            </FieldGroup>
            <section
              className="momo-appearance-preview"
              aria-label={text("appearance.preview")}
            >
              <p>{text("appearance.preview")}</p>
              <div className="momo-palette-strip">
                {Object.entries({
                  base: palette.surfaces.bg,
                  header: palette.roles.header,
                  panel: palette.surfaces.panel,
                  text: palette.surfaces.text,
                  action: palette.accent,
                  selection: palette.roles.selection,
                }).map(([role, value]) => (
                  <span key={role} className="appearance-palette-color">
                    <i style={{ background: value }} />
                    {text("appearance.role." + role)}
                  </span>
                ))}
              </div>
              <div className="momo-preview-sample" inert>
                <header>
                  {text("appearance.sampleWorkspace")}
                  <Button size="sm">{text("appearance.samplePrimary")}</Button>
                </header>
                <div className="momo-tabs">
                  <button aria-pressed="true">
                    {text("appearance.samplePanel")}
                  </button>
                  <button aria-pressed="false">
                    {text("appearance.sampleLibrary")}
                  </button>
                </div>
                <div className="momo-preview-content">
                  <div className="momo-preview-selection">
                    {text("appearance.sampleSelection")}
                  </div>
                  <section className="momo-module">
                    <h3>{text("appearance.sampleParameters")}</h3>
                    <div className="momo-module-body">
                      <Field>
                        <FieldLabel>
                          {text("appearance.sampleValue")}
                        </FieldLabel>
                        <Input readOnly value="62" tabIndex={-1} />
                      </Field>
                    </div>
                  </section>
                </div>
              </div>
              <p>{text("appearance.previewHint")}</p>
            </section>
          </div>
          <p className="wb:text-sm wb:text-destructive" role="status">
            {status ? text(status) : ""}
          </p>
          <DialogFooter>
            <Button variant="outline" data-cancel onClick={close}>
              {text("appearance.cancel")}
            </Button>
            <Button data-save onClick={save}>
              {text("appearance.save")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
