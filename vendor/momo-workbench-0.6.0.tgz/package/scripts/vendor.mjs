// Creates browser-native ESM snapshots from the installed, versioned package.
import {readFile,mkdir,readdir,writeFile,rm} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';

const args=process.argv.slice(2),at=args.indexOf('--target');
if(at<0||!args[at+1]||args.some((arg,i)=>arg!=='--check'&&i!==at&&i!==at+1))throw new Error('Usage: node scripts/vendor.mjs --target <snapshot-directory> [--check]');
const target=path.resolve(args[at+1]),root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),source=path.join(root,'src');
if(target===root||target===source||source.startsWith(target+path.sep))throw new Error('Snapshot target cannot contain the package source');
const pkg=JSON.parse(await readFile(path.join(root,'package.json'),'utf8'));
// React views are bundled by consumers; browser snapshots contain data services and shared CSS.
const entries=(await readdir(source,{withFileTypes:true})).filter(e=>e.isFile()&&!['index.js','index.d.ts'].includes(e.name)&&/\.(?:js|css|ts)$/.test(e.name)).map(e=>e.name).sort();
const files={},buffers=new Map();
for(const name of entries){const data=await readFile(path.join(source,name));buffers.set(name,data);files[name]=createHash('sha256').update(data).digest('hex');}
const manifest={package:pkg.name,version:pkg.version,files};
if(args.includes('--check')){
 const actual=JSON.parse(await readFile(path.join(target,'workbench-manifest.json'),'utf8'));
 if(JSON.stringify(actual)!==JSON.stringify(manifest))throw new Error('Workbench snapshot manifest differs from installed package; regenerate it');
 for(const name of entries){const actual=await readFile(path.join(target,name));if(createHash('sha256').update(actual).digest('hex')!==files[name])throw new Error('Modified Workbench snapshot: '+name);}
 console.log(`${pkg.name}@${pkg.version}: ${entries.length} snapshot files verified`);
}else{
 await mkdir(target,{recursive:true});
 let old;try{old=JSON.parse(await readFile(path.join(target,'workbench-manifest.json'),'utf8'));}catch{}
 // Remove only previously generated flat files, never recursively remove directories.
 for(const name of Object.keys(old?.files??{})){if(path.basename(name)===name&&!Object.hasOwn(files,name))await rm(path.join(target,name),{force:true});}
 for(const [name,data]of buffers)await writeFile(path.join(target,name),data);
 await writeFile(path.join(target,'workbench-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
 await writeFile(path.join(target,'README.md'),`Generated from ${pkg.name}@${pkg.version}. Do not edit these files.\nRun the installed package scripts/vendor.mjs to refresh or --check this snapshot.\n`);
 console.log(`${pkg.name}@${pkg.version}: ${entries.length} files synchronized to ${target}`);
}
