import { useThemedSurface } from "@/react/context";
import { useMessages } from "@/react/context";
import * as React from "react";
import { Dialog as DialogPrimitive } from "@base-ui/react/dialog";
import { cn } from "@/react/lib/utils";

import { Button } from "@/react/components/ui/button";
import { XIcon } from "lucide-react";

function Dialog({ ...props }: DialogPrimitive.Root.Props) {
  return <DialogPrimitive.Root data-slot="dialog" {...props} />;
}

function DialogTrigger({ ...props }: DialogPrimitive.Trigger.Props) {
  return <DialogPrimitive.Trigger data-slot="dialog-trigger" {...props} />;
}

function DialogPortal({ ...props }: DialogPrimitive.Portal.Props) {
  return <DialogPrimitive.Portal data-slot="dialog-portal" {...props} />;
}

function DialogClose({ ...props }: DialogPrimitive.Close.Props) {
  return <DialogPrimitive.Close data-slot="dialog-close" {...props} />;
}

function DialogOverlay({
  className,
  ...props
}: DialogPrimitive.Backdrop.Props) {
  return (
    <DialogPrimitive.Backdrop
      data-slot="dialog-overlay"
      className={cn(
        "wb:fixed wb:inset-0 wb:isolate wb:z-50 wb:bg-black/10 wb:duration-100 wb:supports-backdrop-filter:backdrop-blur-xs wb:data-open:animate-in wb:data-open:fade-in-0 wb:data-closed:animate-out wb:data-closed:fade-out-0",
        className,
      )}
      {...props}
    />
  );
}

function DialogContent({
  ref,
  className,
  children,
  showCloseButton = true,
  closeLabel,
  ...props
}: DialogPrimitive.Popup.Props & {
  showCloseButton?: boolean;
  closeLabel?: string;
}) {
  const surface = useThemedSurface(ref);
  const { text } = useMessages();
  return (
    <DialogPortal>
      <DialogOverlay />
      <DialogPrimitive.Popup
        data-slot="dialog-content"
        data-momo-ui=""
        ref={surface}
        className={cn(
          "wb:fixed wb:top-1/2 wb:left-1/2 wb:z-50 wb:grid wb:w-full wb:max-w-[calc(100%-2rem)] wb:-translate-x-1/2 wb:-translate-y-1/2 wb:gap-4 wb:rounded-xl wb:bg-popover wb:p-4 wb:text-sm wb:text-popover-foreground wb:ring-1 wb:ring-foreground/10 wb:duration-100 wb:outline-none wb:sm:max-w-sm wb:data-open:animate-in wb:data-open:fade-in-0 wb:data-open:zoom-in-95 wb:data-closed:animate-out wb:data-closed:fade-out-0 wb:data-closed:zoom-out-95",
          className,
        )}
        {...props}
      >
        {children}
        {showCloseButton && (
          <DialogPrimitive.Close
            data-slot="dialog-close"
            render={
              <Button
                variant="ghost"
                className="wb:absolute wb:top-2 wb:right-2"
                size="icon-sm"
              />
            }
          >
            <XIcon />
            <span className="wb:sr-only">
              {closeLabel ?? text("common.close")}
            </span>
          </DialogPrimitive.Close>
        )}
      </DialogPrimitive.Popup>
    </DialogPortal>
  );
}

function DialogHeader({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="dialog-header"
      className={cn("wb:flex wb:flex-col wb:gap-2", className)}
      {...props}
    />
  );
}

function DialogFooter({
  className,
  showCloseButton = false,
  children,
  closeLabel,
  ...props
}: React.ComponentProps<"div"> & {
  showCloseButton?: boolean;
  closeLabel?: string;
}) {
  const { text } = useMessages();
  return (
    <div
      data-slot="dialog-footer"
      className={cn(
        "wb:-mx-4 wb:-mb-4 wb:flex wb:flex-col-reverse wb:gap-2 wb:rounded-b-xl wb:border-t wb:bg-muted/50 wb:p-4 wb:sm:flex-row wb:sm:justify-end",
        className,
      )}
      {...props}
    >
      {children}
      {showCloseButton && (
        <DialogPrimitive.Close render={<Button variant="outline" />}>
          {closeLabel ?? text("common.close")}
        </DialogPrimitive.Close>
      )}
    </div>
  );
}

function DialogTitle({ className, ...props }: DialogPrimitive.Title.Props) {
  return (
    <DialogPrimitive.Title
      data-slot="dialog-title"
      className={cn(
        "wb: wb:text-base wb:leading-none wb:font-medium",
        className,
      )}
      {...props}
    />
  );
}

function DialogDescription({
  className,
  ...props
}: DialogPrimitive.Description.Props) {
  return (
    <DialogPrimitive.Description
      data-slot="dialog-description"
      className={cn(
        "wb:text-sm wb:text-muted-foreground wb:*:[a]:underline wb:*:[a]:underline-offset-3 wb:*:[a]:hover:text-foreground",
        className,
      )}
      {...props}
    />
  );
}

export {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogOverlay,
  DialogPortal,
  DialogTitle,
  DialogTrigger,
};
