import * as React from "react";
import { Input as InputPrimitive } from "@base-ui/react/input";
import { cn } from "@/react/lib/utils";

function Input({ className, type, ...props }: React.ComponentProps<"input">) {
  return (
    <InputPrimitive
      type={type}
      data-slot="input"
      data-momo-ui=""
      className={cn(
        "wb:h-8 wb:w-full wb:min-w-0 wb:rounded-lg wb:border wb:border-input wb:bg-transparent wb:px-2.5 wb:py-1 wb:text-base wb:transition-colors wb:outline-none wb:file:inline-flex wb:file:h-6 wb:file:border-0 wb:file:bg-transparent wb:file:text-sm wb:file:font-medium wb:file:text-foreground wb:placeholder:text-muted-foreground wb:focus-visible:border-ring wb:focus-visible:ring-3 wb:focus-visible:ring-ring/50 wb:disabled:pointer-events-none wb:disabled:cursor-not-allowed wb:disabled:bg-input/50 wb:disabled:opacity-50 wb:aria-invalid:border-destructive wb:aria-invalid:ring-3 wb:aria-invalid:ring-destructive/20 wb:md:text-sm wb:dark:bg-input/30 wb:dark:disabled:bg-input/80 wb:dark:aria-invalid:border-destructive/50 wb:dark:aria-invalid:ring-destructive/40",
        className,
      )}
      {...props}
    />
  );
}

export { Input };
