import { useThemedSurface } from "@/react/context";
("use client");

import * as React from "react";
import { Select as SelectPrimitive } from "@base-ui/react/select";
import { cn } from "@/react/lib/utils";
import { ChevronDownIcon, CheckIcon, ChevronUpIcon } from "lucide-react";

const Select = SelectPrimitive.Root;

function SelectGroup({ className, ...props }: SelectPrimitive.Group.Props) {
  return (
    <SelectPrimitive.Group
      data-slot="select-group"
      className={cn("wb:scroll-my-1 wb:p-1", className)}
      {...props}
    />
  );
}

function SelectValue({ className, ...props }: SelectPrimitive.Value.Props) {
  return (
    <SelectPrimitive.Value
      data-slot="select-value"
      className={cn("wb:flex wb:flex-1 wb:text-left", className)}
      {...props}
    />
  );
}

function SelectTrigger({
  className,
  size = "default",
  children,
  ...props
}: SelectPrimitive.Trigger.Props & {
  size?: "sm" | "default";
}) {
  return (
    <SelectPrimitive.Trigger
      data-slot="select-trigger"
      data-size={size}
      className={cn(
        "wb:flex wb:w-fit wb:items-center wb:justify-between wb:gap-1.5 wb:rounded-lg wb:border wb:border-input wb:bg-transparent wb:py-2 wb:pr-2 wb:pl-2.5 wb:text-sm wb:whitespace-nowrap wb:transition-colors wb:outline-none wb:select-none wb:focus-visible:border-ring wb:focus-visible:ring-3 wb:focus-visible:ring-ring/50 wb:disabled:cursor-not-allowed wb:disabled:opacity-50 wb:aria-invalid:border-destructive wb:aria-invalid:ring-3 wb:aria-invalid:ring-destructive/20 wb:data-placeholder:text-muted-foreground wb:data-[size=default]:h-8 wb:data-[size=sm]:h-7 wb:data-[size=sm]:rounded-[min(var(--radius-md),10px)] wb:*:data-[slot=select-value]:line-clamp-1 wb:*:data-[slot=select-value]:flex wb:*:data-[slot=select-value]:items-center wb:*:data-[slot=select-value]:gap-1.5 wb:dark:bg-input/30 wb:dark:hover:bg-input/50 wb:dark:aria-invalid:border-destructive/50 wb:dark:aria-invalid:ring-destructive/40 wb:[&_svg]:pointer-events-none wb:[&_svg]:shrink-0 wb:[&_svg:not([class*=size-])]:size-4",
        className,
      )}
      {...props}
    >
      {children}
      <SelectPrimitive.Icon
        render={
          <ChevronDownIcon className="wb:pointer-events-none wb:size-4 wb:text-muted-foreground" />
        }
      />
    </SelectPrimitive.Trigger>
  );
}

function SelectContent({
  ref,
  className,
  children,
  side = "bottom",
  sideOffset = 4,
  align = "center",
  alignOffset = 0,
  alignItemWithTrigger = true,
  ...props
}: SelectPrimitive.Popup.Props &
  Pick<
    SelectPrimitive.Positioner.Props,
    "align" | "alignOffset" | "side" | "sideOffset" | "alignItemWithTrigger"
  >) {
  const surface = useThemedSurface(ref);
  return (
    <SelectPrimitive.Portal>
      <SelectPrimitive.Positioner
        side={side}
        sideOffset={sideOffset}
        align={align}
        alignOffset={alignOffset}
        alignItemWithTrigger={alignItemWithTrigger}
        className="wb:isolate wb:z-50"
      >
        <SelectPrimitive.Popup
          data-slot="select-content"
          data-momo-ui=""
          ref={surface}
          data-align-trigger={alignItemWithTrigger}
          className={cn(
            "wb:relative wb:isolate wb:z-50 wb:max-h-(--available-height) wb:w-(--anchor-width) wb:min-w-36 wb:origin-(--transform-origin) wb:overflow-x-hidden wb:overflow-y-auto wb:rounded-lg wb:bg-popover wb:text-popover-foreground wb:shadow-md wb:ring-1 wb:ring-foreground/10 wb:duration-100 wb:data-[align-trigger=true]:animate-none wb:data-[side=bottom]:slide-in-from-top-2 wb:data-[side=inline-end]:slide-in-from-left-2 wb:data-[side=inline-start]:slide-in-from-right-2 wb:data-[side=left]:slide-in-from-right-2 wb:data-[side=right]:slide-in-from-left-2 wb:data-[side=top]:slide-in-from-bottom-2 wb:data-open:animate-in wb:data-open:fade-in-0 wb:data-open:zoom-in-95 wb:data-closed:animate-out wb:data-closed:fade-out-0 wb:data-closed:zoom-out-95",
            className,
          )}
          {...props}
        >
          <SelectScrollUpButton />
          <SelectPrimitive.List>{children}</SelectPrimitive.List>
          <SelectScrollDownButton />
        </SelectPrimitive.Popup>
      </SelectPrimitive.Positioner>
    </SelectPrimitive.Portal>
  );
}

function SelectLabel({
  className,
  ...props
}: SelectPrimitive.GroupLabel.Props) {
  return (
    <SelectPrimitive.GroupLabel
      data-slot="select-label"
      className={cn(
        "wb:px-1.5 wb:py-1 wb:text-xs wb:text-muted-foreground",
        className,
      )}
      {...props}
    />
  );
}

function SelectItem({
  className,
  children,
  ...props
}: SelectPrimitive.Item.Props) {
  return (
    <SelectPrimitive.Item
      data-slot="select-item"
      className={cn(
        "wb:relative wb:flex wb:w-full wb:cursor-default wb:items-center wb:gap-1.5 wb:rounded-md wb:py-1 wb:pr-8 wb:pl-1.5 wb:text-sm wb:outline-hidden wb:select-none wb:focus:bg-accent wb:focus:text-accent-foreground wb:not-data-[variant=destructive]:focus:**:text-accent-foreground wb:data-disabled:pointer-events-none wb:data-disabled:opacity-50 wb:[&_svg]:pointer-events-none wb:[&_svg]:shrink-0 wb:[&_svg:not([class*=size-])]:size-4 wb:*:[span]:last:flex wb:*:[span]:last:items-center wb:*:[span]:last:gap-2",
        className,
      )}
      {...props}
    >
      <SelectPrimitive.ItemText className="wb:flex wb:flex-1 wb:shrink-0 wb:gap-2 wb:whitespace-nowrap">
        {children}
      </SelectPrimitive.ItemText>
      <SelectPrimitive.ItemIndicator
        render={
          <span className="wb:pointer-events-none wb:absolute wb:right-2 wb:flex wb:size-4 wb:items-center wb:justify-center" />
        }
      >
        <CheckIcon className="wb:pointer-events-none" />
      </SelectPrimitive.ItemIndicator>
    </SelectPrimitive.Item>
  );
}

function SelectSeparator({
  className,
  ...props
}: SelectPrimitive.Separator.Props) {
  return (
    <SelectPrimitive.Separator
      data-slot="select-separator"
      className={cn(
        "wb:pointer-events-none wb:-mx-1 wb:my-1 wb:h-px wb:bg-border",
        className,
      )}
      {...props}
    />
  );
}

function SelectScrollUpButton({
  className,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.ScrollUpArrow>) {
  return (
    <SelectPrimitive.ScrollUpArrow
      data-slot="select-scroll-up-button"
      className={cn(
        "wb:top-0 wb:z-10 wb:flex wb:w-full wb:cursor-default wb:items-center wb:justify-center wb:bg-popover wb:py-1 wb:[&_svg:not([class*=size-])]:size-4",
        className,
      )}
      {...props}
    >
      <ChevronUpIcon />
    </SelectPrimitive.ScrollUpArrow>
  );
}

function SelectScrollDownButton({
  className,
  ...props
}: React.ComponentProps<typeof SelectPrimitive.ScrollDownArrow>) {
  return (
    <SelectPrimitive.ScrollDownArrow
      data-slot="select-scroll-down-button"
      className={cn(
        "wb:bottom-0 wb:z-10 wb:flex wb:w-full wb:cursor-default wb:items-center wb:justify-center wb:bg-popover wb:py-1 wb:[&_svg:not([class*=size-])]:size-4",
        className,
      )}
      {...props}
    >
      <ChevronDownIcon />
    </SelectPrimitive.ScrollDownArrow>
  );
}

export {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectScrollDownButton,
  SelectScrollUpButton,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
};
