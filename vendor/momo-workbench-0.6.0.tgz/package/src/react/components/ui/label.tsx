"use client";

import * as React from "react";
import { cn } from "@/react/lib/utils";

function Label({ className, ...props }: React.ComponentProps<"label">) {
  return (
    <label
      data-slot="label"
      className={cn(
        "wb:flex wb:items-center wb:gap-2 wb:text-sm wb:leading-none wb:font-medium wb:select-none wb:group-data-[disabled=true]:pointer-events-none wb:group-data-[disabled=true]:opacity-50 wb:peer-disabled:cursor-not-allowed wb:peer-disabled:opacity-50",
        className,
      )}
      {...props}
    />
  );
}

export { Label };
