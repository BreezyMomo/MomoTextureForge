import { useThemedSurface } from "@/react/context";
("use client");

import * as React from "react";
import { Popover as PopoverPrimitive } from "@base-ui/react/popover";
import { cn } from "@/react/lib/utils";

function Popover({ ...props }: PopoverPrimitive.Root.Props) {
  return <PopoverPrimitive.Root data-slot="popover" {...props} />;
}

function PopoverTrigger({ ...props }: PopoverPrimitive.Trigger.Props) {
  return <PopoverPrimitive.Trigger data-slot="popover-trigger" {...props} />;
}

function PopoverContent({
  ref,
  className,
  align = "center",
  alignOffset = 0,
  side = "bottom",
  sideOffset = 4,
  ...props
}: PopoverPrimitive.Popup.Props &
  Pick<
    PopoverPrimitive.Positioner.Props,
    "align" | "alignOffset" | "side" | "sideOffset"
  >) {
  const surface = useThemedSurface(ref);
  return (
    <PopoverPrimitive.Portal>
      <PopoverPrimitive.Positioner
        align={align}
        alignOffset={alignOffset}
        side={side}
        sideOffset={sideOffset}
        className="wb:isolate wb:z-50"
      >
        <PopoverPrimitive.Popup
          data-slot="popover-content"
          data-momo-ui=""
          ref={surface}
          className={cn(
            "wb:z-50 wb:flex wb:w-72 wb:origin-(--transform-origin) wb:flex-col wb:gap-2.5 wb:rounded-lg wb:bg-popover wb:p-2.5 wb:text-sm wb:text-popover-foreground wb:shadow-md wb:ring-1 wb:ring-foreground/10 wb:outline-hidden wb:duration-100 wb:data-[side=bottom]:slide-in-from-top-2 wb:data-[side=inline-end]:slide-in-from-left-2 wb:data-[side=inline-start]:slide-in-from-right-2 wb:data-[side=left]:slide-in-from-right-2 wb:data-[side=right]:slide-in-from-left-2 wb:data-[side=top]:slide-in-from-bottom-2 wb:data-open:animate-in wb:data-open:fade-in-0 wb:data-open:zoom-in-95 wb:data-closed:animate-out wb:data-closed:fade-out-0 wb:data-closed:zoom-out-95",
            className,
          )}
          {...props}
        />
      </PopoverPrimitive.Positioner>
    </PopoverPrimitive.Portal>
  );
}

function PopoverHeader({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="popover-header"
      className={cn("wb:flex wb:flex-col wb:gap-0.5 wb:text-sm", className)}
      {...props}
    />
  );
}

function PopoverTitle({ className, ...props }: PopoverPrimitive.Title.Props) {
  return (
    <PopoverPrimitive.Title
      data-slot="popover-title"
      className={cn("wb:font-medium", className)}
      {...props}
    />
  );
}

function PopoverDescription({
  className,
  ...props
}: PopoverPrimitive.Description.Props) {
  return (
    <PopoverPrimitive.Description
      data-slot="popover-description"
      className={cn("wb:text-muted-foreground", className)}
      {...props}
    />
  );
}

export {
  Popover,
  PopoverContent,
  PopoverDescription,
  PopoverHeader,
  PopoverTitle,
  PopoverTrigger,
};
