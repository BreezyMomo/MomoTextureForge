import { useEffect, useRef, useState, type ComponentProps } from "react";
import { Input } from "./components/ui/input";
import { Slider } from "./components/ui/slider";

type NumberInputProps = Omit<
  ComponentProps<typeof Input>,
  "type" | "value" | "defaultValue" | "onChange" | "min" | "max"
> & {
  label: string;
  value: number;
  min?: number;
  max?: number;
  onValueCommit: (value: number) => void;
};

/** Keep incomplete numeric text local. Only blur or Enter commits a finite value. */
export function WorkbenchNumberInput({
  label,
  value,
  min,
  max,
  onValueCommit,
  onBlur,
  onKeyDown,
  ...props
}: NumberInputProps) {
  const [draft, setDraft] = useState(String(value));
  const cancelled = useRef(false);
  useEffect(() => {
    setDraft(String(value));
  }, [value]);
  const lower = Number.isFinite(min) ? min : undefined;
  const upper = Number.isFinite(max) ? max : undefined;
  return (
    <Input
      {...props}
      aria-label={label}
      type="number"
      min={lower}
      max={upper}
      value={draft}
      onChange={(event) => setDraft(event.target.value)}
      onBlur={(event) => {
        const parsed = Number(draft);
        const next =
          !cancelled.current && draft.trim() && Number.isFinite(parsed)
            ? Math.max(lower ?? -Infinity, Math.min(upper ?? Infinity, parsed))
            : value;
        cancelled.current = false;
        setDraft(String(next));
        if (next !== value) onValueCommit(next);
        onBlur?.(event);
      }}
      onKeyDown={(event) => {
        onKeyDown?.(event);
        if (event.defaultPrevented) return;
        if (event.key === "Enter" || event.key === "Escape") {
          event.preventDefault();
          event.stopPropagation();
          cancelled.current = event.key === "Escape";
          event.currentTarget.blur();
        }
      }}
    />
  );
}

type WorkbenchSliderProps = {
  label: string;
  value: number;
  min?: number;
  max?: number;
  step?: number;
  disabled?: boolean;
  className?: string;
  onValueChange: (value: number) => void;
  onValueCommit?: (value: number) => void;
};
export function WorkbenchSlider({
  label,
  value,
  min = 0,
  max = 100,
  onValueChange,
  onValueCommit,
  disabled,
  ...props
}: WorkbenchSliderProps) {
  const fixed = max <= min;
  return (
    <Slider
      {...props}
      aria-label={label}
      value={[Math.max(min, Math.min(max, value))]}
      min={min}
      max={fixed ? min + 1 : max}
      disabled={disabled || fixed}
      onValueChange={(next) =>
        onValueChange(Array.isArray(next) ? next[0] : (next as number))
      }
      onValueCommitted={(next) =>
        onValueCommit?.(Array.isArray(next) ? next[0] : (next as number))
      }
    />
  );
}
