# MomoWorkbench

MomoTextureForge、MomoPoseForge 与后续系统共用的浏览器工作台。当前版本提取了可注册面板的停靠布局、外观主题、多语言服务与界面动效；各产品保留自己的编辑引擎、对象属性、预设和工程格式。

运行时使用无依赖的 JavaScript ESM，并提供 TypeScript 类型；既可用于原生 DOM，也可由 React 通过稳定的面板容器挂载。模块导入不会创建浏览器单例、读取存储或改动页面。

## 模块

- `@momo/workbench/layout`：`createLayoutModel`，产品注入面板、默认布局、主视口与存储键；提供布局校验和原子操作批次。
- `@momo/workbench/dock`：`createDockWorkspace`，注入 DOM 容器、布局模型、翻译和可选动画；移动已有内容，保留画布上下文。使用结束时调用 `dispose()`。
- `@momo/workbench/appearance`：原有七主题、控件风格、密度、页签与配色，预览和保存分离；指定 `storageKey` 兼容产品旧设置。
- `@momo/workbench/i18n`：语言选择、构建配置、词库、插值、别名之外的界面翻译与消息身份。产品词库由调用者提供，用户输入和工程内容不自动翻译。
- `@momo/workbench/locales`：中英工作台公共文案；产品补充自己的词库。
- `@momo/workbench/motion`：通过 `createMotion({view})` 创建界面动效服务，提供布局 FLIP 过渡、元素动画、拖动边缘滚动与重排预览；跟随系统减少动态效果设置，结束时调用 `dispose()`。
- `@momo/workbench/motion.css`：在 `data-momo-motion` 范围内启用控件、菜单、弹窗与停靠提示动效；原生 `details` 使用 `momo-disclosure` 类获得展开过渡。仅影响界面呈现，不参与作品时间轴。
- `@momo/workbench/dock.css`、`@momo/workbench/theme-tokens.css`：公共样式和主题变量；产品自己的控件、图层和三维视口样式独立维护。

## 验证与发布快照

```powershell
npm test
npm run pack:release
```

将同一个 `momo-workbench-0.2.0.tgz` 放进消费仓库的 `vendor/`，设置依赖为 `"@momo/workbench": "file:vendor/momo-workbench-0.2.0.tgz"`。提交 tgz、依赖锁文件和消费代码，使独立克隆后的 `npm ci` 可用，不依赖开发机的兄弟目录。

对于直接用浏览器加载源码的原生 DOM 产品，从已安装的包生成静态 ESM 快照：

```powershell
node node_modules/@momo/workbench/scripts/vendor.mjs --target web/vendor/momo-workbench
node node_modules/@momo/workbench/scripts/vendor.mjs --target web/vendor/momo-workbench --check
```

快照包含版本和各文件 SHA-256，是发布产物；禁止直接维护第二份实现。消费方构建时检查快照与已安装版本一致。React/Vite 产品可直接导入包的导出入口。

## 接入边界

产品注册稳定的面板 ID、翻译 key、布局预设与独立存储命名空间。DOM 适配器拥有工作台框架节点，产品拥有面板内容。React 应将内容 portal 到稳定容器，关闭或停靠面板时保持编辑器实例，隐藏的面板在 parking 容器中保留，不能通过重建编辑器实现布局切换。

骨架定义、IK/关节限位、纹理合成、参数业务语义、动画重定向、导出与工程迁移仍由产品实现。共享框架不假设某种对象结构，也不强制需要三维视口或时间轴。外观、语言和布局偏好不进入作品文件或撤销历史。

发布方式目前为各仓库固定版本 tgz，未发布到公共 npm；升级需要生成新版本、同步消费快照并通过两产品回归。当前不包含通用属性编辑器、命令注册中心或统一工程格式。
